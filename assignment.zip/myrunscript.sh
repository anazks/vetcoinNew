cd  /home/ubuntu/ledger-waitlist/src; /usr/bin/npm start
