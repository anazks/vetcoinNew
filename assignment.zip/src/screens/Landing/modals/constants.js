/* eslint-disable import/prefer-default-export */
export const MODAL_SCREENS = ['form', 'success'];
